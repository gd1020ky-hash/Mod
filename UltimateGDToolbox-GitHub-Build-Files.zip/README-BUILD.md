# Ultimate GD Toolkit GitHub build

Put this workflow at `.github/workflows/build.yml` in the same repository as the mod source.

Required root files include `mod.json`, `CMakeLists.txt`, and `src/`.

The workflow uses the Geode SDK version from `mod.json` (`sdk: given`) and builds Android64.
